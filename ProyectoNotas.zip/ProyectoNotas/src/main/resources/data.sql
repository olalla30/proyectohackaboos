INSERT INTO estudiante(nombre, apellidos, dni, telefono) VALUES
('nom1', 'ape1', '76859601H', '327244318'),
('nom2', 'ape2', '19835896Y', '688263183'),
('nom3', 'ape3', '24139799B', '376415464'),
('nom4', 'ape4', '93712100A', '999385086'),
('nom5', 'ape5', '36747843F', '933348819'),
('nom6', 'ape6', '53010846D', '205726940'),
('nom7', 'ape7', '15312120P', '921968218'),
('nom8', 'ape8', '51775824H', '963684458'),
('nom9', 'ape9', '77632655L', '952703831');

INSERT INTO materia(nombre, descripcion) VALUES
('Java', 'Java Básico'),
('Spring Boot', 'Marco de trabajo'),
('Hibernate', 'Utilidades Spring Boot'),
('Algoritmos', 'Análisis de ejercicios');

INSERT INTO actividad(nombre, tipo, peso, id_materia) VALUES
('Taller 1', 'Taller', '0.3', 1),
('Taller 2', 'Taller', '0.2', 1),
('Taller 3', 'Taller', '0.5', 1),
('Taller 4', 'Taller', '0.2', 2),
('Taller 5', 'Taller', '0.3', 2),
('Taller 6', 'Taller', '0.1', 2),
('Taller 7', 'Taller', '0.4', 2),
('Parcial 1', 'Parcial', '0.4', 3),
('Parcial 2', 'Parcial', '0.5', 3),
('Parcial 3', 'Parcial', '0.1', 3),
('Filler', 'test', 0.45, 4);

INSERT INTO matricula(id_estudiante, id_materia, nota_final) VALUES
(8, 1, 0),
(4, 4, 0),
(1, 4, 0),
(9, 1, 0),
(4, 2, 0),
(3, 4, 0),
(9, 3, 0),
(7, 4, 0),
(4, 3, 0),
(8, 3, 0),
(9, 2, 0),
(1, 1, 0),
(4, 1, 0),
(6, 2, 0),
(6, 3, 0);

INSERT INTO entrega_actividad(id_matricula, id_actividad, nota_parcial) VALUES
(1, 1, 9.1),
(1, 2, 6.4),
(1, 3, 8.6);

INSERT INTO rol(nombre, permisos) VALUES
('alumno', 'VER'),
('profesor', 'ACTUALIZAR');

INSERT INTO usuario(dni, id_rol, nombre, contrasenia, correo_electronico) VALUES
('76859601H', 1, 'user1', 'pass1', 'mail1'),
('19835896Y', 1, 'user2', 'pass2', 'mail2'),
('24139799B', 1, 'user3', 'pass3', 'mail3'),
('93712100A', 1, 'user4', 'pass4', 'mail4'),
('36747843F', 1, 'user5', 'pass5', 'mail5'),
('13441826M', 2, 'user6', 'pass6', 'mail6')