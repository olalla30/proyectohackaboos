package com.hackaboss.ProyectoNotas.educacion.iRepository;

import com.hackaboss.ProyectoNotas.educacion.entity.Estudiante;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface IEstudianteRepository extends JpaRepository<Estudiante, Long> {

    @Query(value = "SELECT * FROM estudiante WHERE dni = :dni", nativeQuery = true)
    Optional<Estudiante> findByDni(@Param("dni") String dni);
}
