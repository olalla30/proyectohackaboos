package com.hackaboss.ProyectoNotas.educacion.iRepository;

import com.hackaboss.ProyectoNotas.educacion.entity.EntregaActividad;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IEntregaActividadRepository extends JpaRepository<EntregaActividad, Long> {

    @Query(value = "SELECT * FROM entrega_actividad WHERE id_actividad = :id_actividad ORDER BY nota_parcial DESC", nativeQuery = true)
    List<EntregaActividad> findListByGrade(@Param("id_actividad") Long idActividad);
}
