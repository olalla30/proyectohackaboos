package com.hackaboss.ProyectoNotas.educacion.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hackaboss.ProyectoNotas.seguridad.dto.UsuarioDto;

public class MateriaNuevaDto {

    @JsonProperty("nombre")
    private String nombre;

    @JsonProperty("descripcion")
    private String descripcion;

    @JsonProperty("usuarioDto")
    private UsuarioDto usuarioDto;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public UsuarioDto getUsuarioDto() {
        return usuarioDto;
    }

    public void setUsuarioDto(UsuarioDto usuarioDto) {
        this.usuarioDto = usuarioDto;
    }
}
