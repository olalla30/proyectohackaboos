package com.hackaboss.ProyectoNotas.seguridad.service;

import com.hackaboss.ProyectoNotas.educacion.dto.AutorizarDto;
import com.hackaboss.ProyectoNotas.seguridad.dto.UsuarioDto;
import com.hackaboss.ProyectoNotas.seguridad.dto.UsuarioNuevoDto;
import com.hackaboss.ProyectoNotas.seguridad.dto.UsuarioUpdateDto;
import com.hackaboss.ProyectoNotas.seguridad.entity.Rol;
import com.hackaboss.ProyectoNotas.seguridad.entity.Usuario;
import com.hackaboss.ProyectoNotas.seguridad.iRepository.IRolRepository;
import com.hackaboss.ProyectoNotas.seguridad.iRepository.IUsuarioRepository;
import com.hackaboss.ProyectoNotas.seguridad.iService.IUsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService implements IUsuarioService {

    @Autowired
    private IUsuarioRepository repository;

    @Autowired
    private IRolRepository rolRepository;

    @Override
    public List<Usuario> all(UsuarioDto usuarioDto) throws Exception{

        Boolean autorizacionProfesor = authenticatorUserTeacher(usuarioDto.getNombre(), usuarioDto.getContrasenia());

        if (autorizacionProfesor) {
            return repository.findAll();
        } else {
            throw new Exception("No cuenta con la autorización");
        }
    }

    @Override
    public Optional<Usuario> findById(AutorizarDto idDto) throws Exception{

        Boolean autorizacionProfesor = authenticatorUserTeacher(idDto.getUsuarioDto().getNombre(), idDto.getUsuarioDto().getContrasenia());

        if (autorizacionProfesor) {
            return repository.findById(idDto.getId());
        } else {
            throw new Exception("No cuenta con la autorización");
        }
    }

    @Override
    public Usuario save(UsuarioNuevoDto usuarioNuevoDto) throws Exception{

        Boolean autorizacionProfesor = authenticatorUserTeacher(usuarioNuevoDto.getUsuarioDto().getNombre(), usuarioNuevoDto.getUsuarioDto().getContrasenia());

        if (autorizacionProfesor) {
            Usuario usuario = new Usuario();

            Optional<Rol> op = rolRepository.findById(usuarioNuevoDto.getIdRol());
            if (op.isEmpty()) {
                throw new Exception("No se ha encontrado el rol");
            } else {
                Rol rol = op.get();
                usuario.setDni(usuarioNuevoDto.getDni());
                usuario.setRol(rol);
                usuario.setNombre(usuarioNuevoDto.getNombre());
                usuario.setContrasenia(usuarioNuevoDto.getContrasenia());
                usuario.setCorreoElectronico(usuarioNuevoDto.getCorreoElectronico());
            }
            return repository.save(usuario);
        } else {
            throw new Exception("No cuenta con la autorización");
        }
    }

    @Override
    public void update(UsuarioUpdateDto usuarioUpdateDto) throws Exception{

        Boolean autorizacionProfesor = authenticatorUserTeacher(usuarioUpdateDto.getUsuarioDto().getNombre(), usuarioUpdateDto.getUsuarioDto().getContrasenia());

        if (autorizacionProfesor) {
            Optional<Usuario> op = repository.findById(usuarioUpdateDto.getId());

            if (op.isEmpty()) {
                throw new Exception("No se ha encontrado el usuario");
            } else {
                //Crear nuevo objeto que va a contener los datos que se van actualizar
                Usuario usuarioUpdate = op.get();

                Optional<Rol> opRol = rolRepository.findById(usuarioUpdateDto.getIdRol());

                if(opRol.isEmpty()) {
                    throw new Exception("No se ha encontrado el rol");
                } else {
                    Rol rol = opRol.get();

                    usuarioUpdate.setNombre(usuarioUpdateDto.getNombre());
                    usuarioUpdate.setContrasenia(usuarioUpdateDto.getContrasenia());
                    usuarioUpdate.setDni(usuarioUpdateDto.getDni());
                    usuarioUpdate.setRol(rol);
                    usuarioUpdate.setCorreoElectronico(usuarioUpdateDto.getCorreoElectronico());

                    //Actualizar el objeto
                    repository.save(usuarioUpdate);
                }
            }
        } else {
            throw new Exception("No cuenta con la autorización");
        }

    }

    @Override
    public void delete(AutorizarDto borrarDto) throws Exception{

        Boolean autorizacionProfesor = authenticatorUserTeacher(borrarDto.getUsuarioDto().getNombre(), borrarDto.getUsuarioDto().getContrasenia());

        if(autorizacionProfesor) {
            repository.deleteById(borrarDto.getId());
        } else throw new Exception("No cuenta con la autorización");
    }

    @Override
    public BigInteger countUserTeacher(String nombreUsuario, String contrasenia) {
        return repository.countUserTeacher(nombreUsuario, contrasenia);
    }

    public Boolean authenticatorUserTeacher(String nombreUsuario, String contrasenia) {
        BigInteger count = countUserTeacher(nombreUsuario, contrasenia);
        return count.intValue() == 1;
    }
}
