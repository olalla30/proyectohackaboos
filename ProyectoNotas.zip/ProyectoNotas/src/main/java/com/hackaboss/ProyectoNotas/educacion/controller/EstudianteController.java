package com.hackaboss.ProyectoNotas.educacion.controller;

import com.hackaboss.ProyectoNotas.educacion.dto.AutorizarDto;
import com.hackaboss.ProyectoNotas.educacion.dto.EstudianteDto;
import com.hackaboss.ProyectoNotas.educacion.dto.EstudianteNuevoDto;
import com.hackaboss.ProyectoNotas.educacion.entity.Estudiante;
import com.hackaboss.ProyectoNotas.educacion.service.EstudianteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("api/estudiante")
public class EstudianteController {

    @Autowired
    private EstudianteService service;

    @GetMapping
    @ResponseStatus(code = HttpStatus.OK)
    public List<Estudiante> listAll() {
        return service.all();
    }

    @GetMapping("{id}")
    @ResponseStatus(code = HttpStatus.OK)
    public Optional<Estudiante> findById(@PathVariable Long id) {
        return service.findById(id);
    }

    @PostMapping
    @ResponseStatus(code = HttpStatus.CREATED)
    public Estudiante save(@RequestBody EstudianteNuevoDto estudianteNuevoDto) throws Exception{
        return service.save(estudianteNuevoDto);
    }

    @PutMapping
    @ResponseStatus(code = HttpStatus.NO_CONTENT)
    public void update(@RequestBody EstudianteDto estudianteDto)throws Exception {
        service.update(estudianteDto);
    }

    @DeleteMapping
    @ResponseStatus(code = HttpStatus.NO_CONTENT)
    public void delete(@RequestBody AutorizarDto borrarDto) throws Exception{
        service.delete(borrarDto);
    }

    @GetMapping("/dni/{dni}")
    @ResponseStatus(code = HttpStatus.OK)
    public Optional<Estudiante> findByDni(@PathVariable String dni){
        return service.findByDni(dni);
    }
}
