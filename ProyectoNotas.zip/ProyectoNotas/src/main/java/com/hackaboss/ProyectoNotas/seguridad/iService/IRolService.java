package com.hackaboss.ProyectoNotas.seguridad.iService;

import com.hackaboss.ProyectoNotas.educacion.dto.AutorizarDto;
import com.hackaboss.ProyectoNotas.seguridad.dto.RolDto;
import com.hackaboss.ProyectoNotas.seguridad.dto.RolNuevoDto;
import com.hackaboss.ProyectoNotas.seguridad.entity.Rol;

import java.util.List;
import java.util.Optional;

public interface IRolService {

    /**
     * * Método encargado de retornar la lista con todos los registros
     ***/
    List<Rol> all();

    /**
     * * Método encargado de retornar un registro por medio del ID
     ***/
    Optional<Rol> findById(Long id);

    /**
     * *Método encargado de guardar los datos del registro
     ***/
    Rol save(RolNuevoDto rolNuevoDto) throws Exception;

    /**
     * *Método encargado de modificar los datos del registro
     ***/
    void update(RolDto rolDto) throws Exception;

    /**
     * *Método encargado de eliminar un registro
     ***/
    void delete(AutorizarDto borrarDto) throws Exception;

    /**
     * * Método encargado de retornar un registro por medio del nombre
     ***/
    Optional<Rol> findByName(String nombre);
}
