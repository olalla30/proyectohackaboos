package com.hackaboss.ProyectoNotas.educacion.controller;

import com.hackaboss.ProyectoNotas.educacion.dto.ActividadDto;
import com.hackaboss.ProyectoNotas.educacion.dto.ActividadNuevaDto;
import com.hackaboss.ProyectoNotas.educacion.dto.AutorizarDto;
import com.hackaboss.ProyectoNotas.educacion.entity.Actividad;
import com.hackaboss.ProyectoNotas.educacion.service.ActividadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("api/actividad")
public class ActividadController {

    @Autowired
    private ActividadService service;

    @GetMapping
    @ResponseStatus(code = HttpStatus.OK)
    public List<Actividad> findAll() {
        return service.all();
    }

    @GetMapping("{id}")
    @ResponseStatus(code = HttpStatus.OK)
    public Optional<Actividad> findById(@PathVariable Long id) {
        return service.findById(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Actividad save(@RequestBody ActividadNuevaDto actividadNuevaDto) throws Exception {
        return service.save(actividadNuevaDto);
    }

    @PutMapping
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void update(@RequestBody ActividadDto actividadDto) throws Exception {
        service.update(actividadDto);
    }

    @RequestMapping(method = RequestMethod.DELETE)
    @ResponseStatus(code = HttpStatus.NO_CONTENT)
    public void delete(@RequestBody AutorizarDto borrarDto) throws Exception{
        service.delete(borrarDto);
    }

    @GetMapping("/tipo/{tipo}")
    @ResponseStatus(code = HttpStatus.OK)
    public List<Actividad> findListByType(@PathVariable String tipo) {
        return service.findListByType(tipo);
    }

    @GetMapping("/materia/{idMateria}")
    @ResponseStatus(code = HttpStatus.OK)
    public List<Actividad> findListBySubject(@PathVariable Long idMateria) {
        return service.findListBySubject(idMateria);
    }

    @GetMapping("/matricula/{idMatricula}")
    public List<Actividad> findListByStudent(@PathVariable Long idMatricula) {
        return service.findListByStudent(idMatricula);
    }
}
