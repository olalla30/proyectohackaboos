package com.hackaboss.ProyectoNotas.seguridad.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class UsuarioDto {

    @JsonProperty("nombre")
    private String nombre;

    @JsonProperty("contrasenia")
    private String contrasenia;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

}
