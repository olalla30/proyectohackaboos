package com.hackaboss.ProyectoNotas.educacion.iService;

import com.hackaboss.ProyectoNotas.educacion.dto.ActividadDto;
import com.hackaboss.ProyectoNotas.educacion.dto.ActividadNuevaDto;
import com.hackaboss.ProyectoNotas.educacion.dto.AutorizarDto;
import com.hackaboss.ProyectoNotas.educacion.entity.Actividad;

import java.util.List;
import java.util.Optional;

public interface IActividadService {

    /**
     * * Método encargado de retornar la lista con todos los registros
     ***/
    List<Actividad> all();

    /**
     * * Método encargado de retornar un registro por medio del ID
     ***/
    Optional<Actividad> findById(Long id);

    /**
     * *Método encargado de guardar los datos del registro
     ***/
    Actividad save(ActividadNuevaDto actividadNuevaDto) throws Exception;

    /**
     * *Método encargado de modificar los datos del registro
     ***/
    void update(ActividadDto actividadDto) throws Exception;

    /**
     * *Método encargado de eliminar un registro
     ***/
    void delete(AutorizarDto borrarDto) throws Exception;

    /**
     * * Método encargado de retornar la lista con los registros por tipo
     ***/
    List<Actividad> findListByType(String tipo);

    /**
     * * Método encargado de retornar la suma de notas
     ***/
    double findSumOfGrades(Long idMatricula);

    /**
     * * Método encargado de retornar la suma de pesos de las actividades de una materia
     ***/
    double findSumOfWeights(Long idMateria);

    /**
     * * Método encargado de retornar la lista con los registros por materia
     ***/
    List<Actividad> findListBySubject(Long idMateria);

    /**
     * * Método encargado de retornar la lista con los registros por estudiante
     ***/
    List<Actividad> findListByStudent(Long idMatricula);

}
