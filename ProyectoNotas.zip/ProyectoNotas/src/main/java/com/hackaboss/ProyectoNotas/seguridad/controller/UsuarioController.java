package com.hackaboss.ProyectoNotas.seguridad.controller;


import com.hackaboss.ProyectoNotas.educacion.dto.AutorizarDto;
import com.hackaboss.ProyectoNotas.seguridad.dto.UsuarioDto;
import com.hackaboss.ProyectoNotas.seguridad.dto.UsuarioNuevoDto;
import com.hackaboss.ProyectoNotas.seguridad.dto.UsuarioUpdateDto;
import com.hackaboss.ProyectoNotas.seguridad.entity.Usuario;
import com.hackaboss.ProyectoNotas.seguridad.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("api/usuario")
public class UsuarioController {

    @Autowired
    private UsuarioService service;

    @GetMapping
    @ResponseStatus(code = HttpStatus.OK)
    public List<Usuario> findAll(@RequestBody UsuarioDto usuarioDto) throws Exception{
        return service.all(usuarioDto);
    }

    @GetMapping("/id")
    @ResponseStatus(code = HttpStatus.OK)
    public Optional<Usuario> findById(@RequestBody AutorizarDto idDto) throws Exception{
        return service.findById(idDto);
    }

    @PostMapping
    @ResponseStatus(code = HttpStatus.CREATED)
    public Usuario save(@RequestBody UsuarioNuevoDto usuarioNuevoDto) throws Exception{
        return service.save(usuarioNuevoDto);
    }

    @PutMapping
    @ResponseStatus(code = HttpStatus.NO_CONTENT)
    public void update(@RequestBody UsuarioUpdateDto usuarioUpdateDto) throws Exception{
        service.update(usuarioUpdateDto);
    }

    @DeleteMapping
    @ResponseStatus(code = HttpStatus.NO_CONTENT)
    public void delete(@RequestBody AutorizarDto borrarDto) throws Exception{
        service.delete(borrarDto);
    }
}
