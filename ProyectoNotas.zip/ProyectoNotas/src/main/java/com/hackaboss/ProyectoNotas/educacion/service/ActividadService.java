package com.hackaboss.ProyectoNotas.educacion.service;

import com.hackaboss.ProyectoNotas.educacion.dto.ActividadDto;
import com.hackaboss.ProyectoNotas.educacion.dto.ActividadNuevaDto;
import com.hackaboss.ProyectoNotas.educacion.dto.AutorizarDto;
import com.hackaboss.ProyectoNotas.educacion.entity.Actividad;
import com.hackaboss.ProyectoNotas.educacion.entity.Materia;
import com.hackaboss.ProyectoNotas.educacion.iRepository.IActividadRepository;
import com.hackaboss.ProyectoNotas.educacion.iService.IActividadService;
import com.hackaboss.ProyectoNotas.seguridad.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ActividadService implements IActividadService {

    @Autowired
    private IActividadRepository repository;

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private MateriaService materiaService;

    public ActividadService() {
    }

    @Override
    public List<Actividad> all() {
        return repository.findAll();
    }

    @Override
    public Optional<Actividad> findById(Long id) {
        return repository.findById(id);
    }

    @Override
    public Actividad save(ActividadNuevaDto actividadNuevaDto) throws Exception {

        Boolean autorizacionProfesor = usuarioService.authenticatorUserTeacher(actividadNuevaDto.getUsuarioDto().getNombre(), actividadNuevaDto.getUsuarioDto().getContrasenia());

        if (autorizacionProfesor) {
            double sumaPesos = repository.findSumOfWeights(actividadNuevaDto.getIdMateria());

            if (actividadNuevaDto.getPeso() + sumaPesos <= 1) {

                Actividad actividad = new Actividad();
                Optional<Materia> op = materiaService.findById(actividadNuevaDto.getIdMateria());

                actividad.setNombre(actividadNuevaDto.getNombre());
                actividad.setTipo(actividadNuevaDto.getTipo());
                actividad.setPeso(actividadNuevaDto.getPeso());

                if (op.isEmpty()) {
                    throw new Exception("No se ha encontrado la materia");
                } else {
                    Materia materia = op.get();

                    actividad.setMateria(materia);
                }

                return repository.save(actividad);
            } else {
                throw new Exception("Cantidad no permitida");
            }
        } else {
            throw new Exception("No cuenta con la autorización");
        }
    }

    @Override
    public void update(ActividadDto actividadDto) throws Exception {

        Optional<Actividad> op = repository.findById(actividadDto.getId());

        if (op.isEmpty()) {
            throw new Exception("No se ha encontrado la actividad");
        } else {

            Boolean autorizacionProfesor = usuarioService.authenticatorUserTeacher(actividadDto.getUsuarioDto().getNombre(), actividadDto.getUsuarioDto().getContrasenia());

            if (autorizacionProfesor) {
                //Crear nuevo objeto que va a contener los datos que se van actualizar
                Actividad actividadUpdate = op.get();

                double pesoInicial = actividadUpdate.getPeso();
                double sumaPesos = repository.findSumOfWeights(actividadDto.getIdMateria());

                if (actividadDto.getPeso() + (sumaPesos - pesoInicial) <= 1) {

                    actividadUpdate.setNombre(actividadDto.getNombre());
                    actividadUpdate.setTipo(actividadDto.getTipo());
                    actividadUpdate.setPeso(actividadDto.getPeso());

                    //Actualizar el objeto
                    repository.save(actividadUpdate);
                } else {
                    throw new Exception("Cantidad no permitida");
                }
            } else {
                throw new Exception("No cuenta con la autorización");
            }
        }

    }

    @Override
    public void delete(AutorizarDto borrarDto) throws Exception {
        Boolean autorizacionProfesor = usuarioService.authenticatorUserTeacher(borrarDto.getUsuarioDto().getNombre(), borrarDto.getUsuarioDto().getContrasenia());

        if (autorizacionProfesor) {
            repository.deleteById(borrarDto.getId());
        } else {
            throw new Exception("No cuenta con la autorización");
        }
    }

    @Override
    public List<Actividad> findListByType(String tipo) {
        return repository.findListByType(tipo);
    }

    @Override
    public double findSumOfGrades(Long idMatricula) {
        return repository.findSumOfGrades(idMatricula);
    }

    @Override
    public double findSumOfWeights(Long idMateria) {
        return repository.findSumOfWeights(idMateria);
    }

    @Override
    public List<Actividad> findListBySubject(Long idMateria) {
        return repository.findListBySubject(idMateria);
    }

    @Override
    public List<Actividad> findListByStudent(Long idMatricula) {
        return repository.findListByStudent(idMatricula);
    }

}
