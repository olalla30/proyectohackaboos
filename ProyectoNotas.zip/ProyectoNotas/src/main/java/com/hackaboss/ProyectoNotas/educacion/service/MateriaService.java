package com.hackaboss.ProyectoNotas.educacion.service;

import com.hackaboss.ProyectoNotas.educacion.dto.AutorizarDto;
import com.hackaboss.ProyectoNotas.educacion.dto.MateriaDto;
import com.hackaboss.ProyectoNotas.educacion.dto.MateriaNuevaDto;
import com.hackaboss.ProyectoNotas.educacion.entity.Materia;
import com.hackaboss.ProyectoNotas.educacion.iRepository.IMateriaRepository;
import com.hackaboss.ProyectoNotas.educacion.iService.IMateriaService;
import com.hackaboss.ProyectoNotas.seguridad.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MateriaService implements IMateriaService {

    @Autowired
    private IMateriaRepository repository;

    @Autowired
    private UsuarioService usuarioService;

    @Override
    public List<Materia> all() {
        return repository.findAll();
    }

    @Override
    public Optional<Materia> findById(Long id) {
        return repository.findById(id);
    }

    @Override
    public Materia save(MateriaNuevaDto materiaNuevaDto) throws Exception{

        Boolean autorizacionProfesor = usuarioService.authenticatorUserTeacher(materiaNuevaDto.getUsuarioDto().getNombre(), materiaNuevaDto.getUsuarioDto().getContrasenia());

        if(autorizacionProfesor) {
            Materia materia = new Materia();
            materia.setNombre(materiaNuevaDto.getNombre());
            materia.setDescripcion(materiaNuevaDto.getDescripcion());

            return repository.save(materia);
        } else {
            throw new Exception("No cuenta con la autorización");
        }
    }

    @Override
    public void update(MateriaDto materiaDto) throws Exception{

        Boolean autorizacionProfesor = usuarioService.authenticatorUserTeacher(materiaDto.getUsuarioDto().getNombre(), materiaDto.getUsuarioDto().getContrasenia());

        if(autorizacionProfesor) {
            Optional<Materia> op = repository.findById(materiaDto.getId());

            if (op.isEmpty()) {
                throw new Exception("No se ha encontrado la materia");
            } else {
                //Crear nuevo objeto que va a contener los datos que se van actualizar
                Materia materiaUpdate = op.get();

                materiaUpdate.setNombre(materiaDto.getNombre());
                materiaUpdate.setDescripcion(materiaDto.getDescripcion());

                //Actualizar el objeto
                repository.save(materiaUpdate);
            }
        } else {
            throw new Exception("No cuenta con la autorzación");
        }

    }

    @Override
    public void delete(AutorizarDto borrarDto) throws Exception{

        Boolean autorizacionProfesor = usuarioService.authenticatorUserTeacher(borrarDto.getUsuarioDto().getNombre(), borrarDto.getUsuarioDto().getContrasenia());

        if(autorizacionProfesor) {
            repository.deleteById(borrarDto.getId());
        } else {
            throw new Exception("No cuenta con la autorización");
        }

    }

    @Override
    public Optional<Materia> findByName(String nombre) {
        return repository.findByName(nombre);
    }

    @Override
    public List<Materia> findListByStudent(Long id_Estudiante) {
        return repository.findListByStudent(id_Estudiante);
    }
}
