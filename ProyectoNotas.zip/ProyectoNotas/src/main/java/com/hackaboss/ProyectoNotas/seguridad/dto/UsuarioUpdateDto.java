package com.hackaboss.ProyectoNotas.seguridad.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class UsuarioUpdateDto {

    @JsonProperty("id")
    private Long id;

    @JsonProperty("dni")
    private String dni;

    @JsonProperty("idRol")
    private Long idRol;

    @JsonProperty("nombre")
    private String nombre;

    @JsonProperty("contrasenia")
    private String contrasenia;

    @JsonProperty("correoElectronico")
    private String correoElectronico;

    @JsonProperty("usuarioDto")
    private UsuarioDto usuarioDto;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public Long getIdRol() {
        return idRol;
    }

    public void setIdRol(Long idRol) {
        this.idRol = idRol;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public UsuarioDto getUsuarioDto() {
        return usuarioDto;
    }

    public void setUsuarioDto(UsuarioDto usuarioDto) {
        this.usuarioDto = usuarioDto;
    }
}
