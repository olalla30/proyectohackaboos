package com.hackaboss.ProyectoNotas.seguridad.service;

import com.hackaboss.ProyectoNotas.educacion.dto.AutorizarDto;
import com.hackaboss.ProyectoNotas.seguridad.dto.RolDto;
import com.hackaboss.ProyectoNotas.seguridad.dto.RolNuevoDto;
import com.hackaboss.ProyectoNotas.seguridad.entity.Rol;
import com.hackaboss.ProyectoNotas.seguridad.iRepository.IRolRepository;
import com.hackaboss.ProyectoNotas.seguridad.iService.IRolService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RolService implements IRolService {

    @Autowired
    private IRolRepository repository;

    @Autowired
    private UsuarioService usuarioService;

    @Override
    public List<Rol> all() {
        return repository.findAll();
    }

    @Override
    public Optional<Rol> findById(Long id) {
        return repository.findById(id);
    }

    @Override
    public Rol save(RolNuevoDto rolNuevoDto) throws Exception{

        Boolean autorizacionProfesor = usuarioService.authenticatorUserTeacher(rolNuevoDto.getUsuarioDto().getNombre(), rolNuevoDto.getUsuarioDto().getContrasenia());

        if(autorizacionProfesor) {
            Rol rol = new Rol();

            rol.setNombre(rolNuevoDto.getNombre());
            rol.setPermisos(rolNuevoDto.getPermisos());

            return repository.save(rol);
        } else {
            throw new Exception("No cuenta con la autorización");
        }
    }

    @Override
    public void update(RolDto rolDto) throws Exception{

        Boolean autorizacionProfesor = usuarioService.authenticatorUserTeacher(rolDto.getUsuarioDto().getNombre(), rolDto.getUsuarioDto().getContrasenia());

        if (autorizacionProfesor) {

            Optional<Rol> op = repository.findById(rolDto.getId());

            if (op.isEmpty()) {
                throw new Exception("No se ha encontrado el rol");
            } else {
                //Crear nuevo objeto que va a contener los datos que se van actualizar
                Rol rolUpdate = op.get();

                rolUpdate.setNombre(rolDto.getNombre());
                rolUpdate.setPermisos(rolDto.getPermisos());

                //Actualizar el objeto
                repository.save(rolUpdate);
            }

        } else {
            throw new Exception("No cuenta con la autorización");
        }
    }

    @Override
    public void delete(AutorizarDto borrarDto) throws Exception{

        Boolean autorizacionProfesor = usuarioService.authenticatorUserTeacher(borrarDto.getUsuarioDto().getNombre(), borrarDto.getUsuarioDto().getContrasenia());

        if(autorizacionProfesor) {
            repository.deleteById(borrarDto.getId());
        } else throw new Exception("No cuenta con la autorización");
    }

    @Override
    public Optional<Rol> findByName(String nombre) {
        return repository.findByName(nombre);
    }
}
