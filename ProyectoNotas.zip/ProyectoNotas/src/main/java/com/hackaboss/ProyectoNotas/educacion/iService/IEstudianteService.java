package com.hackaboss.ProyectoNotas.educacion.iService;

import com.hackaboss.ProyectoNotas.educacion.dto.AutorizarDto;
import com.hackaboss.ProyectoNotas.educacion.dto.EstudianteDto;
import com.hackaboss.ProyectoNotas.educacion.dto.EstudianteNuevoDto;
import com.hackaboss.ProyectoNotas.educacion.entity.Estudiante;

import java.util.List;
import java.util.Optional;

public interface IEstudianteService {

    /**
     * * Método encargado de retornar la lista con todos los registros
     ***/
    List<Estudiante> all();

    /**
     * * Método encargado de retornar un registro por medio del ID
     ***/
    Optional<Estudiante> findById(Long id);

    /**
     * * Método encargado de retornar un registro por medio del DNI
     ***/
    Optional<Estudiante> findByDni(String dni);

    /**
     * *Método encargado de guardar los datos del registro
     ***/
    Estudiante save(EstudianteNuevoDto estudianteNuevoDto) throws Exception;

    /**
     * *Método encargado de modificar los datos del registro
     ***/
    void update(EstudianteDto estudianteDto) throws Exception;

    /**
     * *Método encargado de eliminar un registro
     ***/
    void delete(AutorizarDto borrarDto) throws Exception;

}
