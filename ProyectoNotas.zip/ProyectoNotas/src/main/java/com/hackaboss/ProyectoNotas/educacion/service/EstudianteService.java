package com.hackaboss.ProyectoNotas.educacion.service;

import com.hackaboss.ProyectoNotas.educacion.dto.AutorizarDto;
import com.hackaboss.ProyectoNotas.educacion.dto.EstudianteDto;
import com.hackaboss.ProyectoNotas.educacion.dto.EstudianteNuevoDto;
import com.hackaboss.ProyectoNotas.educacion.entity.Estudiante;
import com.hackaboss.ProyectoNotas.educacion.iRepository.IEstudianteRepository;
import com.hackaboss.ProyectoNotas.educacion.iService.IEstudianteService;
import com.hackaboss.ProyectoNotas.seguridad.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EstudianteService implements IEstudianteService {

    @Autowired
    private IEstudianteRepository repository;

    @Autowired
    private UsuarioService usuarioService;

    @Override
    public List<Estudiante> all() {
        return repository.findAll();
    }

    @Override
    public Optional<Estudiante> findById(Long id) {
        return repository.findById(id);
    }

    @Override
    public Optional<Estudiante> findByDni(String dni) {
        return repository.findByDni(dni);
    }

    @Override
    public Estudiante save(EstudianteNuevoDto estudianteNuevoDto) throws Exception{

        Boolean autorizacionProfesor = usuarioService.authenticatorUserTeacher(estudianteNuevoDto.getUsuarioDto().getNombre(), estudianteNuevoDto.getUsuarioDto().getContrasenia());

        if(autorizacionProfesor) {
            Estudiante estudiante = new Estudiante();
            estudiante.setNombre(estudianteNuevoDto.getNombre());
            estudiante.setApellidos(estudianteNuevoDto.getApellidos());
            estudiante.setDni(estudianteNuevoDto.getDni());
            estudiante.setTelefono(estudianteNuevoDto.getTelefono());

            return repository.save(estudiante);
        } else {
            throw new Exception("No cuenta con la autorización");
        }
    }

    @Override
    public void update(EstudianteDto estudianteDto) throws Exception{

        Boolean autorizacionProfesor = usuarioService.authenticatorUserTeacher(estudianteDto.getUsuarioDto().getNombre(), estudianteDto.getUsuarioDto().getContrasenia());

        if(autorizacionProfesor) {
            Optional<Estudiante> op = repository.findById(estudianteDto.getId());

            if (op.isEmpty()) {
                throw new Exception("No se ha encontrado el estudiante");
            } else {
                //Crear nuevo objeto que va a contener los datos que se van actualizar
                Estudiante estudianteUpdate = op.get();

                estudianteUpdate.setNombre(estudianteDto.getNombre());
                estudianteUpdate.setApellidos(estudianteDto.getApellidos());
                estudianteUpdate.setDni(estudianteDto.getDni());
                estudianteUpdate.setTelefono(estudianteDto.getTelefono());

                //Actualizar el objeto
                repository.save(estudianteUpdate);
            }
        } else {
            throw new Exception("No cuenta con la autorización");
        }
    }

    @Override
    public void delete(AutorizarDto borrarDto) throws Exception{
        Boolean autorizacionProfesor = usuarioService.authenticatorUserTeacher(borrarDto.getUsuarioDto().getNombre(), borrarDto.getUsuarioDto().getContrasenia());

        if(autorizacionProfesor) {
            repository.deleteById(borrarDto.getId());
        } else {
            throw new Exception("No cuenta con la autorización");
        }
    }
}
