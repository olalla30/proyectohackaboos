package com.hackaboss.ProyectoNotas.educacion.iRepository;

import com.hackaboss.ProyectoNotas.educacion.entity.Matricula;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IMatriculaRepository extends JpaRepository<Matricula, Long> {

    @Query(value = "SELECT * FROM matricula WHERE id_materia = :id_materia ORDER BY nota_final DESC", nativeQuery = true)
    List<Matricula> findListByGrade(@Param("id_materia") Long materiaId);

    @Query(value = "SELECT COUNT(*) FROM matricula WHERE id_materia = :id_materia", nativeQuery = true)
    int numberOfStudentsBySubject(@Param("id_materia") Long idMateria);
}
