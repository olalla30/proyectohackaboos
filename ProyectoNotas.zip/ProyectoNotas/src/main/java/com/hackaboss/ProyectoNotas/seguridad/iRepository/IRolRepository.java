package com.hackaboss.ProyectoNotas.seguridad.iRepository;

import com.hackaboss.ProyectoNotas.seguridad.entity.Rol;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface IRolRepository extends JpaRepository<Rol, Long> {

    @Query(value = "SELECT * FROM rol WHERE nombre = :nombre_rol", nativeQuery = true)
    Optional<Rol> findByName(@Param("nombre_rol") String nombreRol);
}
