package com.hackaboss.ProyectoNotas.educacion.controller;

import com.hackaboss.ProyectoNotas.educacion.dto.AutorizarDto;
import com.hackaboss.ProyectoNotas.educacion.dto.MateriaDto;
import com.hackaboss.ProyectoNotas.educacion.dto.MateriaNuevaDto;
import com.hackaboss.ProyectoNotas.educacion.entity.Materia;
import com.hackaboss.ProyectoNotas.educacion.service.MateriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("api/materia")
public class MateriaController {

    @Autowired
    private MateriaService service;

    @GetMapping
    @ResponseStatus(code = HttpStatus.OK)
    public List<Materia> findAll() {
        return service.all();
    }

    @GetMapping("{id}")
    @ResponseStatus(code = HttpStatus.OK)
    public Optional<Materia> findById(@PathVariable Long id) {
        return service.findById(id);
    }

    @PostMapping
    @ResponseStatus(code = HttpStatus.CREATED)
    public Materia save(@RequestBody MateriaNuevaDto materiaNuevaDto) throws Exception{
        return service.save(materiaNuevaDto);
    }

    @PutMapping
    @ResponseStatus(code = HttpStatus.NO_CONTENT)
    public void update(@RequestBody MateriaDto materiaDto) throws Exception{
        service.update(materiaDto);
    }

    @DeleteMapping
    @ResponseStatus(code = HttpStatus.NO_CONTENT)
    public void delete(@RequestBody AutorizarDto borrarDto) throws Exception{
        service.delete(borrarDto);
    }

    @GetMapping("/nombre/{nombre}")
    @ResponseStatus(code = HttpStatus.OK)
    public Optional<Materia> findByName(@PathVariable String nombre) {
        return service.findByName(nombre);
    }

    @GetMapping("/estudiante/{idEstudiante}")
    @ResponseStatus(code = HttpStatus.OK)
    public List<Materia> findListByStudent(@PathVariable Long idEstudiante) {
        return service.findListByStudent(idEstudiante);
    }
}
