package com.hackaboss.ProyectoNotas.educacion.controller;


import com.hackaboss.ProyectoNotas.educacion.dto.AutorizarDto;
import com.hackaboss.ProyectoNotas.educacion.dto.EntregaActividadDto;
import com.hackaboss.ProyectoNotas.educacion.dto.EntregaActividadNuevoDto;
import com.hackaboss.ProyectoNotas.educacion.entity.EntregaActividad;
import com.hackaboss.ProyectoNotas.educacion.service.EntregaActividadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("api/entrega_actividad")
public class EnregaActividadController {

    @Autowired
    private EntregaActividadService service;

    @GetMapping
    @ResponseStatus(code = HttpStatus.OK)
    public List<EntregaActividad> findAll() {
        return service.all();
    }

    @GetMapping("{id}")
    @ResponseStatus(code = HttpStatus.OK)
    public Optional<EntregaActividad> findById(@PathVariable Long id) {
        return service.findById(id);
    }

    @PostMapping
    @ResponseStatus(code = HttpStatus.CREATED)
    public EntregaActividad save(@RequestBody EntregaActividadNuevoDto entregaActividadNuevoDto) throws Exception{
        return service.save(entregaActividadNuevoDto);
    }

    @PutMapping
    @ResponseStatus(code = HttpStatus.NO_CONTENT)
    public void update(@RequestBody EntregaActividadDto entregaActividadDto) throws Exception{
        service.update(entregaActividadDto);
    }

    @DeleteMapping
    @ResponseStatus(code = HttpStatus.NO_CONTENT)
    public void delete(@RequestBody AutorizarDto borrarDto) throws Exception{
        service.delete(borrarDto);
    }

    @GetMapping("/actividad/{idActividad}")
    public List<EntregaActividad> listByGrade(@PathVariable Long idActividad) {
        return service.findListByGrade(idActividad);
    }
}
