package com.hackaboss.ProyectoNotas.educacion.iService;

import com.hackaboss.ProyectoNotas.educacion.dto.AutorizarDto;
import com.hackaboss.ProyectoNotas.educacion.dto.MatriculaDto;
import com.hackaboss.ProyectoNotas.educacion.dto.MatriculaNuevaDto;
import com.hackaboss.ProyectoNotas.educacion.entity.Matricula;

import java.util.List;
import java.util.Optional;

public interface IMatriculaService {
    /**
     * * Método encargado de retornar la lista con todos los registros
     ***/
    List<Matricula> all();

    /**
     * * Método encargado de retornar un registro por medio del ID
     ***/
    Optional<Matricula> findById(Long id);

    /**
     * *Método encargado de guardar los datos del registro
     ***/
    Matricula save(MatriculaNuevaDto matriculaNuevaDto) throws Exception;

    /**
     * *Método encargado de modificar los datos del registro
     ***/
    void update(MatriculaDto matriculaDto) throws Exception;

    /**
     * *Método encargado de eliminar un registro
     ***/
    void delete(AutorizarDto borrarDto) throws Exception;

    /**
     * * Método encargado de retornar la lista con todos los registros relacionados con una materia ordenados por nota
     ***/
    List<Matricula> findListByGrade(Long idMateria);

    /**
     * *Método encargado de modificar la nota final
     ***/
    void updateFinalGrade(AutorizarDto notaFinalDto) throws Exception;

    int numberOfStudentsBySubject(Long idMateria);

}
