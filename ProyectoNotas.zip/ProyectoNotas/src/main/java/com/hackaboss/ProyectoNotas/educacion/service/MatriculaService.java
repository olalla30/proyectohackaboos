package com.hackaboss.ProyectoNotas.educacion.service;

import com.hackaboss.ProyectoNotas.educacion.dto.AutorizarDto;
import com.hackaboss.ProyectoNotas.educacion.dto.MatriculaDto;
import com.hackaboss.ProyectoNotas.educacion.dto.MatriculaNuevaDto;
import com.hackaboss.ProyectoNotas.educacion.entity.Estudiante;
import com.hackaboss.ProyectoNotas.educacion.entity.Materia;
import com.hackaboss.ProyectoNotas.educacion.entity.Matricula;
import com.hackaboss.ProyectoNotas.educacion.iRepository.IMatriculaRepository;
import com.hackaboss.ProyectoNotas.educacion.iService.IMatriculaService;
import com.hackaboss.ProyectoNotas.seguridad.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MatriculaService implements IMatriculaService {

    @Autowired
    private IMatriculaRepository repository;

    @Autowired
    private ActividadService actividadService;

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private MateriaService materiaService;

    @Autowired
    private EstudianteService estudianteService;

    @Override
    public List<Matricula> all() {
        return repository.findAll();
    }

    @Override
    public Optional<Matricula> findById(Long id) {
        return repository.findById(id);
    }

    @Override
    public Matricula save(MatriculaNuevaDto matriculaNuevaDto) throws Exception {

        Boolean autorizacionProfesor = usuarioService.authenticatorUserTeacher(matriculaNuevaDto.getUsuarioDto().getNombre(), matriculaNuevaDto.getUsuarioDto().getContrasenia());

        if (autorizacionProfesor) {

            Optional<Materia> opMateria = materiaService.findById(matriculaNuevaDto.getIdMateria());
            Optional<Estudiante> opEstudiante = estudianteService.findById(matriculaNuevaDto.getIdEstudiante());

            if (opMateria.isEmpty() || opEstudiante.isEmpty()) {
                throw new Exception("No se ha encontrado la materia o el estudiante");
            } else {
                if (repository.numberOfStudentsBySubject(matriculaNuevaDto.getIdMateria()) < 25) {
                    Materia materia = opMateria.get();
                    Estudiante estudiante = opEstudiante.get();

                    Matricula matricula = new Matricula();

                    matricula.setEstudiante(estudiante);
                    matricula.setMateria(materia);
                    matricula.setNotaFinal(0.0);

                    return repository.save(matricula);
                } else {
                    throw new Exception("Se ha alcanzado el máximo de matrículas para esa materia");
                }
            }

        } else {
            throw new Exception("No cuenta con la autorización");
        }

    }

    @Override
    public void update(MatriculaDto matriculaDto) throws Exception {

        Boolean autorizacionProfesor = usuarioService.authenticatorUserTeacher(matriculaDto.getUsuarioDto().getNombre(), matriculaDto.getUsuarioDto().getContrasenia());

        if (autorizacionProfesor) {

            Optional<Matricula> op = repository.findById(matriculaDto.getId());

            if (op.isEmpty()) {
                throw new Exception("No se ha encontrado la matrícula");
            } else {
                if (repository.numberOfStudentsBySubject(matriculaDto.getIdMateria()) < 25) {
                    //Crear nuevo objeto que va a contener los datos que se van actualizar
                    Matricula matriculaUpdate = op.get();

                    Optional<Materia> opMateria = materiaService.findById(matriculaDto.getIdMateria());
                    Optional<Estudiante> opEstudiante = estudianteService.findById(matriculaDto.getIdEstudiante());

                    if(opMateria.isEmpty() || opEstudiante.isEmpty()) {
                        throw new Exception("No se ha encontrado la materia o el estudiante");
                    } else {
                        Materia materia = opMateria.get();
                        Estudiante estudiante = opEstudiante.get();

                        matriculaUpdate.setMateria(materia);
                        matriculaUpdate.setEstudiante(estudiante);
                    }

                    //Actualizar el objeto
                    repository.save(matriculaUpdate);
                } else {
                    throw new Exception("Se ha alcanzado el máximo de matrículas para esa materia");
                }

            }
        } else {
            throw new Exception("No cuenta con la autorización");
        }
    }

    @Override
    public void delete(AutorizarDto borrarDto) throws Exception {

        Boolean autorizacionProfesor = usuarioService.authenticatorUserTeacher(borrarDto.getUsuarioDto().getNombre(), borrarDto.getUsuarioDto().getContrasenia());

        if (autorizacionProfesor) {
            repository.deleteById(borrarDto.getId());
        } else throw new Exception("No cuenta con la autorización");
    }

    @Override
    public List<Matricula> findListByGrade(Long idMateria) {
        return repository.findListByGrade(idMateria);
    }

    @Override
    public void updateFinalGrade(AutorizarDto notaFinalDto) throws Exception{

        Boolean autorizacionProfesor = usuarioService.authenticatorUserTeacher(notaFinalDto.getUsuarioDto().getNombre(), notaFinalDto.getUsuarioDto().getContrasenia());

        if(autorizacionProfesor) {
            Optional<Matricula> op = repository.findById(notaFinalDto.getId());

            if (op.isEmpty()) {
                throw new Exception("No se ha encontrado la matrícula");
            } else {
                Matricula matriculaUpdate = op.get();

                matriculaUpdate.setNotaFinal(actividadService.findSumOfGrades(matriculaUpdate.getId()));

                //Actualizar el objeto
                repository.save(matriculaUpdate);
            }
        } else {
            throw new Exception("No cuenta con la autorización");
        }

    }

    @Override
    public int numberOfStudentsBySubject(Long idMateria) {
        return repository.numberOfStudentsBySubject(idMateria);
    }
}
