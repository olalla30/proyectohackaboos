package com.hackaboss.ProyectoNotas.seguridad.iService;

import com.hackaboss.ProyectoNotas.educacion.dto.AutorizarDto;
import com.hackaboss.ProyectoNotas.seguridad.dto.UsuarioDto;
import com.hackaboss.ProyectoNotas.seguridad.dto.UsuarioNuevoDto;
import com.hackaboss.ProyectoNotas.seguridad.dto.UsuarioUpdateDto;
import com.hackaboss.ProyectoNotas.seguridad.entity.Usuario;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

public interface IUsuarioService {


    /**
     * * Método encargado de retornar la lista con todos los registros
     ***/

    List<Usuario> all(UsuarioDto usuarioDto) throws Exception;

    /**
     * * Método encargado de retornar un registro por medio del ID
     ***/
    Optional<Usuario> findById(AutorizarDto idDto) throws Exception;

    /**
     * *Método encargado de guardar los datos del registro
     ***/
    Usuario save(UsuarioNuevoDto usuarioNuevoDto) throws Exception;

    /**
     * *Método encargado de modificar los datos del registro
     ***/
    void update(UsuarioUpdateDto usuarioUpdateDto) throws Exception;

    /**
     * *Método encargado de eliminar un registro
     ***/
    void delete(AutorizarDto borrarDto) throws Exception;

    BigInteger countUserTeacher(String nombreUsuario, String contrasenia);
}
