package com.hackaboss.ProyectoNotas.enums;

public enum Permisos {
    VER, ACTUALIZAR
}
