package com.hackaboss.ProyectoNotas.educacion.iRepository;

import com.hackaboss.ProyectoNotas.educacion.entity.Materia;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface IMateriaRepository extends JpaRepository<Materia, Long> {

    @Query(value = "SELECT * FROM materia WHERE nombre = :nombre", nativeQuery = true)
    Optional<Materia> findByName(@Param("nombre") String nombre);

    @Query(value = "SELECT" +
            " *" +
            " FROM" +
            " matricula ma" +
            " INNER JOIN materia mat ON" +
            " mat.id = ma.id_materia" +
            " WHERE" +
            " ma.id_estudiante = :id_estudiante", nativeQuery = true)
    List<Materia> findListByStudent(@Param("id_estudiante") Long idEstudiante);
}
