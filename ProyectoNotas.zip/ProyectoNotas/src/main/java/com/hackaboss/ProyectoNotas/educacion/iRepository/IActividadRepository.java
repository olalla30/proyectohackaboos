package com.hackaboss.ProyectoNotas.educacion.iRepository;

import com.hackaboss.ProyectoNotas.educacion.entity.Actividad;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IActividadRepository extends JpaRepository<Actividad, Long> {

    @Query(value =  "SELECT *" +
            " FROM actividad" +
            " WHERE tipo = :tipo",
            nativeQuery = true)
    List<Actividad> findListByType(@Param("tipo") String tipo);

    @Query(value = "SELECT" +
            " SUM(b.nota_parcial * a.peso)" +
            " FROM actividad a" +
            " INNER JOIN entrega_actividad b ON" +
            " b.id_matricula = a.id" +
            " WHERE id_matricula = :id_matricula" , nativeQuery = true)
    double findSumOfGrades(@Param("id_matricula") Long idMatricula);

    @Query(value = "SELECT" +
            " COALESCE(SUM(a.peso),0)" +
            " FROM actividad a" +
            " INNER JOIN materia b ON" +
            " b.id = a.id_materia" +
            " WHERE id_materia = :id_materia", nativeQuery = true)
    double findSumOfWeights(@Param("id_materia") Long idMateria);

    @Query(value = "SELECT * FROM actividad WHERE id_materia = :id_materia", nativeQuery = true)
    List<Actividad> findListBySubject(@Param("id_materia") Long idMateria);

    @Query(value = " select"
            + "	a.id,"
            + " a.nombre,"
            + " a.peso,"
            + " a.tipo,"
            + " a.id_materia"
            + " from materia m"
            + "	inner join actividad a ON m.id = a.id_materia"
            + " inner join matricula ma on m.id = ma.id_materia"
            + " where ma.id = :id_matricula ", nativeQuery = true)
    List<Actividad> findListByStudent(@Param("id_matricula") Long idMatricula);

}
