package com.hackaboss.ProyectoNotas.educacion.service;

import com.hackaboss.ProyectoNotas.educacion.dto.AutorizarDto;
import com.hackaboss.ProyectoNotas.educacion.dto.EntregaActividadDto;
import com.hackaboss.ProyectoNotas.educacion.dto.EntregaActividadNuevoDto;
import com.hackaboss.ProyectoNotas.educacion.entity.Actividad;
import com.hackaboss.ProyectoNotas.educacion.entity.EntregaActividad;
import com.hackaboss.ProyectoNotas.educacion.entity.Matricula;
import com.hackaboss.ProyectoNotas.educacion.iRepository.IEntregaActividadRepository;
import com.hackaboss.ProyectoNotas.educacion.iService.IEntregaActividadService;
import com.hackaboss.ProyectoNotas.seguridad.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EntregaActividadService implements IEntregaActividadService {

    @Autowired
    private IEntregaActividadRepository repository;

    @Autowired
    private ActividadService actividadService;

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private MatriculaService matriculaService;

    @Override
    public List<EntregaActividad> all() {
        return repository.findAll();
    }

    @Override
    public Optional<EntregaActividad> findById(Long id) {
        return repository.findById(id);
    }

    @Override
    public EntregaActividad save(EntregaActividadNuevoDto entregaActividadNuevoDto) throws Exception {

        Boolean autorizacionProfesor = usuarioService.authenticatorUserTeacher(entregaActividadNuevoDto.getUsuarioDto().getNombre(), entregaActividadNuevoDto.getUsuarioDto().getContrasenia());

        if (autorizacionProfesor) {

            Optional<Matricula> opMatricula = matriculaService.findById(entregaActividadNuevoDto.getIdmatricula());
            Optional<Actividad> opActividad = actividadService.findById(entregaActividadNuevoDto.getIdActividad());

            if (opMatricula.isEmpty() || opActividad.isEmpty()) {
                throw new Exception("No se ha encontrado la actividad o la matrícula");
            } else {
                List<Actividad> listaActividades = actividadService.findListByStudent(entregaActividadNuevoDto.getIdmatricula());

                for (Actividad a : listaActividades) {
                    if (entregaActividadNuevoDto.getIdActividad() == a.getId()) {
                        EntregaActividad entregaActividad = new EntregaActividad();
                        Matricula matricula = opMatricula.get();

                        entregaActividad.setMatricula(matricula);
                        entregaActividad.setIdActividad(entregaActividadNuevoDto.getIdActividad());
                        entregaActividad.setNotaParcial(entregaActividadNuevoDto.getNotaParcial());

                        return repository.save(entregaActividad);
                    } else {
                        throw new Exception("La actividad no se corresponde con la matrícula");
                    }
                }
            }

        } else {
            throw new Exception("No cuenta con la autorización");
        }
        throw new Exception("...");
    }

    @Override
    public void update(EntregaActividadDto entregaActividadDto) throws Exception{

        Boolean autorizacionProfesor = usuarioService.authenticatorUserTeacher(entregaActividadDto.getUsuarioDto().getNombre(), entregaActividadDto.getUsuarioDto().getContrasenia());

        if (autorizacionProfesor) {
            Optional<EntregaActividad> op = repository.findById(entregaActividadDto.getId());

            if (op.isEmpty()) {
                throw new Exception("No se ha encontrado la entrega");
            } else {
                //Crear nuevo objeto que va a contener los datos que se van actualizar
                EntregaActividad entregaActividadUpdate = op.get();

                entregaActividadUpdate.setNotaParcial(entregaActividadDto.getNotaParcial());

                //Actualizar el objeto
                repository.save(entregaActividadUpdate);
            }
        } else {
            throw new Exception("No cuenta con la autorización");
        }
    }

    @Override
    public void delete(AutorizarDto borrarDto) throws Exception {
        Boolean autorizacionProfesor = usuarioService.authenticatorUserTeacher(borrarDto.getUsuarioDto().getNombre(), borrarDto.getUsuarioDto().getContrasenia());

        if (autorizacionProfesor) {
            repository.deleteById(borrarDto.getId());
        } else {
            throw new Exception("No cuenta con la autorización");
        }
    }

    @Override
    public List<EntregaActividad> findListByGrade(Long idActividad) {
        return repository.findListByGrade(idActividad);
    }
}
