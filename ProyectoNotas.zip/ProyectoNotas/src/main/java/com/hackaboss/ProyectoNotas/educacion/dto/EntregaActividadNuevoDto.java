package com.hackaboss.ProyectoNotas.educacion.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hackaboss.ProyectoNotas.educacion.entity.Matricula;
import com.hackaboss.ProyectoNotas.seguridad.dto.UsuarioDto;

public class EntregaActividadNuevoDto {

    @JsonProperty("idMatricula")
    private Long idMatricula;

    @JsonProperty("idActividad")
    private Long idActividad;

    @JsonProperty("notaParcial")
    private double notaParcial;

    @JsonProperty("usuarioDto")
    private UsuarioDto usuarioDto;

    public Long getIdmatricula() {
        return idMatricula;
    }

    public void setIdmatricula(Long idMatricula) {
        this.idMatricula = idMatricula;
    }

    public Long getIdActividad() {
        return idActividad;
    }

    public void setIdActividad(Long idActividad) {
        this.idActividad = idActividad;
    }

    public double getNotaParcial() {
        return notaParcial;
    }

    public void setNotaParcial(double notaParcial) {
        this.notaParcial = notaParcial;
    }

    public UsuarioDto getUsuarioDto() {
        return usuarioDto;
    }

    public void setUsuarioDto(UsuarioDto usuarioDto) {
        this.usuarioDto = usuarioDto;
    }

}
