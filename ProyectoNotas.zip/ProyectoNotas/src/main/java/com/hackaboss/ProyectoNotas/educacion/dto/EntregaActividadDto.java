package com.hackaboss.ProyectoNotas.educacion.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hackaboss.ProyectoNotas.educacion.entity.Matricula;
import com.hackaboss.ProyectoNotas.seguridad.dto.UsuarioDto;

public class EntregaActividadDto {

    @JsonProperty("id")
    private Long id;

    @JsonProperty("notaParcial")
    private double notaParcial;

    @JsonProperty("usuarioDto")
    private UsuarioDto usuarioDto;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public double getNotaParcial() {
        return notaParcial;
    }

    public void setNotaParcial(double notaParcial) {
        this.notaParcial = notaParcial;
    }

    public UsuarioDto getUsuarioDto() {
        return usuarioDto;
    }

    public void setUsuarioDto(UsuarioDto usuarioDto) {
        this.usuarioDto = usuarioDto;
    }
}
