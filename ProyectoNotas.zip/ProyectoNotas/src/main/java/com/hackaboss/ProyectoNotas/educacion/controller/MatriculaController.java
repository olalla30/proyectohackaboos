package com.hackaboss.ProyectoNotas.educacion.controller;

import com.hackaboss.ProyectoNotas.educacion.dto.AutorizarDto;
import com.hackaboss.ProyectoNotas.educacion.dto.MatriculaDto;
import com.hackaboss.ProyectoNotas.educacion.dto.MatriculaNuevaDto;
import com.hackaboss.ProyectoNotas.educacion.entity.Matricula;
import com.hackaboss.ProyectoNotas.educacion.service.MatriculaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("api/matricula")
public class MatriculaController {

    @Autowired
    private MatriculaService service;

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public List<Matricula> findAll() {
        return service.all();
    }

    @GetMapping("{id}")
    public Optional<Matricula> findById(@PathVariable Long id) {
        return service.findById(id);
    }

    @PostMapping
    @ResponseStatus(code = HttpStatus.CREATED)
    public Matricula save(@RequestBody MatriculaNuevaDto matriculaNuevaDto) throws Exception{
        return service.save(matriculaNuevaDto);}

    @PutMapping
    @ResponseStatus(code = HttpStatus.NO_CONTENT)
    public void update(@RequestBody MatriculaDto matriculaDto) throws Exception{
        service.update(matriculaDto);
    }

    @DeleteMapping
    @ResponseStatus(code = HttpStatus.NO_CONTENT)
    public void delete(@RequestBody AutorizarDto borrarDto) throws Exception{
        service.delete(borrarDto);
    }

    @GetMapping("/nota/{idMateria}")
    @ResponseStatus(code = HttpStatus.OK)
    public List<Matricula> listByGrade(@PathVariable Long idMateria) {
        return service.findListByGrade(idMateria);
    }

    @PutMapping("/notaFinal")
    @ResponseStatus(code = HttpStatus.NO_CONTENT)
    public void updateFinalGrade(@RequestBody AutorizarDto notaFinalDto) throws Exception{
        service.updateFinalGrade(notaFinalDto);
    }

    @GetMapping("/materia/{idMateria}")
    @ResponseStatus(code = HttpStatus.OK)
    public int findNumberOfStudents(@PathVariable Long idMateria) {
        return service.numberOfStudentsBySubject(idMateria);
    }

}
