package com.hackaboss.ProyectoNotas.educacion.iService;

import com.hackaboss.ProyectoNotas.educacion.dto.AutorizarDto;
import com.hackaboss.ProyectoNotas.educacion.dto.EntregaActividadDto;
import com.hackaboss.ProyectoNotas.educacion.dto.EntregaActividadNuevoDto;
import com.hackaboss.ProyectoNotas.educacion.entity.EntregaActividad;

import java.util.List;
import java.util.Optional;

public interface IEntregaActividadService {
    /**
     * * Método encargado de retornar la lista con todos los registros
     ***/
    List<EntregaActividad> all();

    /**
     * * Método encargado de retornar un registro por medio del ID
     ***/
    Optional<EntregaActividad> findById(Long id);

    /**
     * *Método encargado de guardar los datos del registro
     ***/
    EntregaActividad save(EntregaActividadNuevoDto entregaActividadNuevoDto) throws Exception;

    /**
     * *Método encargado de modificar los datos del registro
     ***/
    void update(EntregaActividadDto entregaActividadDto) throws Exception;

    /**
     * *Método encargado de eliminar un registro
     ***/
    void delete(AutorizarDto borrarDto) throws Exception;

    /**
     * * Método encargado de retornar la lista con todos los registros relacionados con una actividad ordenados por nota
     ***/
    List<EntregaActividad> findListByGrade(Long actividadId);
}
