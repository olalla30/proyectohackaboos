package com.hackaboss.ProyectoNotas.educacion.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hackaboss.ProyectoNotas.educacion.entity.Estudiante;
import com.hackaboss.ProyectoNotas.educacion.entity.Materia;
import com.hackaboss.ProyectoNotas.educacion.entity.Matricula;
import com.hackaboss.ProyectoNotas.seguridad.dto.UsuarioDto;

public class MatriculaDto {

    @JsonProperty("id")
    private Long id;

    @JsonProperty("idEstudiante")
    private Long idEstudiante;

    @JsonProperty("idMateria")
    private Long idMateria;

    @JsonProperty("usuarioDto")
    private UsuarioDto usuarioDto;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getIdEstudiante() {
        return idEstudiante;
    }

    public void setIdEstudiante(Long idEstudiante) {
        this.idEstudiante = idEstudiante;
    }

    public Long getIdMateria() {
        return idMateria;
    }

    public void setIdMateria(Long idMateria) {
        this.idMateria = idMateria;
    }

    public UsuarioDto getUsuarioDto() {
        return usuarioDto;
    }

    public void setUsuarioDto(UsuarioDto usuarioDto) {
        this.usuarioDto = usuarioDto;
    }
}
