package com.hackaboss.ProyectoNotas.seguridad.controller;


import com.hackaboss.ProyectoNotas.educacion.dto.AutorizarDto;
import com.hackaboss.ProyectoNotas.seguridad.dto.RolDto;
import com.hackaboss.ProyectoNotas.seguridad.dto.RolNuevoDto;
import com.hackaboss.ProyectoNotas.seguridad.entity.Rol;
import com.hackaboss.ProyectoNotas.seguridad.service.RolService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("api/rol")
public class RolController {
    @Autowired
    private RolService service;

    @GetMapping
    @ResponseStatus(code = HttpStatus.OK)
    public List<Rol> findAll() {
        return service.all();
    }

    @GetMapping("{id}")
    @ResponseStatus(code = HttpStatus.OK)
    public Optional<Rol> findById(@PathVariable Long id) {
        return service.findById(id);
    }

    @PostMapping
    @ResponseStatus(code = HttpStatus.CREATED)
    public Rol save(@RequestBody RolNuevoDto rolNuevoDto) throws Exception{
        return service.save(rolNuevoDto);
    }

    @PutMapping
    @ResponseStatus(code = HttpStatus.NO_CONTENT)
    public void update(@RequestBody RolDto rolDto) throws Exception{
        service.update(rolDto);
    }

    @DeleteMapping
    @ResponseStatus(code = HttpStatus.NO_CONTENT)
    public void delete(@RequestBody AutorizarDto borrarDto) throws Exception{
        service.delete(borrarDto);
    }

    @GetMapping("/nombre/{nombre}")
    @ResponseStatus(code = HttpStatus.OK)
    public Optional<Rol> findByName(@PathVariable String nombre) {
        return service.findByName(nombre);
    }

}
