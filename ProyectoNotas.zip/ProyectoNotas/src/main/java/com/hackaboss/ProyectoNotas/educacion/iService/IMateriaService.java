package com.hackaboss.ProyectoNotas.educacion.iService;

import com.hackaboss.ProyectoNotas.educacion.dto.AutorizarDto;
import com.hackaboss.ProyectoNotas.educacion.dto.MateriaDto;
import com.hackaboss.ProyectoNotas.educacion.dto.MateriaNuevaDto;
import com.hackaboss.ProyectoNotas.educacion.entity.Materia;

import java.util.List;
import java.util.Optional;

public interface IMateriaService {

    /**
     * * Método encargado de retornar la lista con todos los registros
     ***/
    List<Materia> all();

    /**
     * * Método encargado de retornar un registro por medio del ID
     ***/
    Optional<Materia> findById(Long id);

    /**
     * *Método encargado de guardar los datos del registro
     ***/
    Materia save(MateriaNuevaDto materiaNuevaDto) throws Exception;

    /**
     * *Método encargado de modificar los datos del registro
     ***/
    void update(MateriaDto materiaDto) throws Exception;

    /**
     * *Método encargado de eliminar un registro
     ***/
    void delete(AutorizarDto borrarDto) throws Exception;

    /**
     * * Método encargado de retornar un registro por medio del nombre
     ***/
    Optional<Materia> findByName(String nombre);

    /**
     * * Método encargado de retornar la lista con las materias cursadas por un estudiante
     ***/
    List<Materia> findListByStudent(Long id_Estudiante);
}
