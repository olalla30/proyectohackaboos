package com.hackaboss.ProyectoNotas.seguridad.iRepository;

import com.hackaboss.ProyectoNotas.seguridad.entity.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;

@Repository
public interface IUsuarioRepository extends JpaRepository<Usuario, Long> {

    @Query(value =
            "SELECT COUNT(u.id) " +
                    "FROM usuario u " +
                    "INNER JOIN rol r ON u.id_rol = r.id " +
                    "WHERE " +
                    "  u.nombre = :nombre AND " +
                    "  u.contrasenia = :contrasenia AND " +
                    "  u.id_rol = 2", nativeQuery = true)
    BigInteger countUserTeacher(@Param("nombre") String nombreUsuario, @Param("contrasenia") String contrasenia);
}
