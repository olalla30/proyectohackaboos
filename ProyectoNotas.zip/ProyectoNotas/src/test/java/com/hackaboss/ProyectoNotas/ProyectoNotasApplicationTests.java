package com.hackaboss.ProyectoNotas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoNotasApplicationTests {

	@Test
	void contextLoads() {
	}

}
